function cat_generator(){
    var image = document.createElement('img')
    image.src = "https://media3.giphy.com/media/O0w5OYPG9XMpS6XqtP/giphy.gif?cid=ecf05e47xrm7bz15bwk06owpf3zqol1iyysdwovuz9mbohmo&rid=giphy.gif&ct=g"
    var div = document.getElementById("img-results")
    div.appendChild(image)

}
